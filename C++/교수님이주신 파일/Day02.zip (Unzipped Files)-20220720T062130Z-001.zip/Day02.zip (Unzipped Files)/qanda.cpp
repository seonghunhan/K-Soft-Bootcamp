//#include <iostream>
//#include <string>
//using namespace std;
//
//int main() {
//	string a = "kimtaeyoung";
//	string b = "inha";
//
//	a = a + b;
//	cout << a << '\n';
//
//	return 0;
//}

//#include <iostream>
//#include <cstring>
//using namespace std;
//
//int main() {
//	const char* p2 = "inha";
//	int* p1 = new int[3];
//	*p1 = 999;
//	*(p1 + 1) = -7;
//	*(p1 + 2) = 37;
//	cout << *p1 << '\n';
//	cout << *(p1 + 2) << '\n';
//	cout << p1[1] << '\n';
//	cout << strlen(p2) << '\n';
//
//	delete[] p1;
//	p1 = nullptr;
//
//	//int* p1 = new int;
//	//*p1 = 999;
//	//cout << *p1 << '\n';
//
//	//delete p1;
//	//p1 = nullptr;
//	return 0;
//}
