//#include <iostream>
//using namespace std;
//
//int main(){
//    int a = 19;
//    int b(89);
//    int c{ 7 };
//    cout << a << b << c;
//    cout << '\n';
//    return 0;
//}