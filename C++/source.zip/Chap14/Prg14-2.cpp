﻿/**************************************************************
 * 오류 메시지를 출력하며 프로그램을 중단하는 프로그램        *
 **************************************************************/
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
  int num1, num2, result;
  for(int i = 0; i < 5; i++)
  {
    cout << "정수를 입력하세요: ";
    cin >> num1;
    cout << "또 다른 정수를 입력하세요: ";
    cin >> num2;
    if(num2 == 0)
    {
      cout << "0으로 나눌 수 없습니다.프로그램을 중단합니다." << endl;
      assert(false);
    }
    result = num1 / num2;
    cout << "결과 = " << result << endl;
  }  
  return 0;
}