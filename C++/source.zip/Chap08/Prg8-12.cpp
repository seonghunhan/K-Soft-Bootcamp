﻿/**************************************************************
 * 여러 Student 객체를 생성하고                               *
 * 이름, 성적, 학점을 출력                                    *
 **************************************************************/
#include "student.h"

int main()
{
  // 기본 생성자로 배열 생성
  Student students[5];
  // 매개변수가 있는 생성자로 객체 5개 인스턴스화
  students[0] = Student("George", 82);
  students[1] = Student("John", 73);
  students[2] = Student("Luci", 91);
  students[3] = Student("Mary", 72);
  students[4] = Student("Sue", 65);
  // 학생의 이름, 성적, 학점 출력
  for(int i = 0; i < 5; i++)
  {
    students[i].print();
  }
  return 0;
} 