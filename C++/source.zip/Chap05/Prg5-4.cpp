﻿/***************************************************************
* while 반복문으로 수열의 합 구하기                            *
****************************************************************/ 
#include <iostream>
using namespace std;

int main()  
{
  // 선언하고 초기화
  int sum1 = 0, sum2 = 0, sum3 = 0;
  int n;
  // 변수 n 입력받기
  cout << "n의 값 입력: ";
  cin >> n;
  // while 반복문
  int counter = 1;    // 카운터 초기화
  while(counter <= n) 
  {
    sum1 += counter;
    sum2 += counter * counter;
    sum3 += counter * counter * counter; 
    counter++;  // 카운터 변경 
  }
  // 결과 출력
  cout << "n의 값 = " << n << endl;
  cout << "sum1의 값: " << sum1 << endl;
  cout << "sum2의 값: " << sum2 << endl;
  cout << "sum3의 값: " << sum3 << endl;
  return 0; 
}