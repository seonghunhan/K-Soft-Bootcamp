﻿/************************************************************
 * 사용자로부터 정수를 입력받고 do-while을 이용하여         *
 * 가장 왼쪽으로 숫자를 출력하는 프로그램                   *
 ************************************************************/
#include <iostream>
using namespace std;

int main()
{
  // 선언
  int num;
  short leftDigit;
  // 입력받기
  cout << "음수가 아닌 정수를 입력하세요: ";
  cin >> num;
  // 반복문
  do 
  {
    leftDigit = num % 10;
     num = num / 10;
  } while(num > 0); 
  // 출력
  cout << "가장 왼쪽의 숫자 = " << leftDigit << endl;
  return 0; 
} 