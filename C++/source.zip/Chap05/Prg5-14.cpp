﻿/*************************************************************
 * 반복문을 중첩해서 * 기호를 정해진 패턴으로                *
 * 출력하는 프로그램                                         *
 *************************************************************/ 
#include <iostream>
using namespace std;

int main()
{
  // 선언
  int rows;     // 행의 수
  int cols;     // 열의 수
  // 입력받기
  cout << "행의 수를 입력하세요: ";
  cin >> rows;
  cout << "열의 수를 입력하세요: ";
  cin >> cols;
  // 출력
  for(int count1 = 1; count1 <= rows; count1++)
  {
    for(int count2 = 1; count2 <= cols; count2++)
    { 
      cout << "*";
    }  
    cout << endl;
  } 
  return 0;
}