﻿/*************************************************************
 * 작은 것을 찾는 smaller 함수를 자료형 별로 구현한 프로그램 *
 *************************************************************/
#include <iostream>
using namespace std;

// 두 문자 중에 작은 것을 찾는 함수
char smaller(char first, char second)
{
  if(first < second)
  {
    return first;
  }
  return second;
}
// 두 정수 중에 작은 것을 찾는 함수
int smaller(int first, int second)
{
  if(first < second)
  {
    return first;
  }
  return second;
}
// 두 부동 소수점 중에 작은 것을 찾는 함수
double smaller(double first, double second)
{
  if(first < second)
  {
    return first;
  }
  return second;
}

int main()
{
  cout << "a와 B 중에 작은 것 = " << smaller('a', 'B') << endl;
  cout << "12와 15 중에 작은 것 = " << smaller(12, 15) << endl;
  cout << "44.2와 33.1 중에 작은 것 = " << smaller(44.2, 33.1) << endl;
  return 0;
}