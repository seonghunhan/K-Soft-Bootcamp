﻿/*************************************************************
 * char 자료형의 변수를 선언하고 초기화하는 프로그램         *
 *************************************************************/
#include <iostream>
using namespace std;

int main()
{
  // char 자료형의 변수를 선언하고 초기화
  char first = 'A';
  char second = 65;
  char third = 'B';
  char fourth = 66;
  // 값 출력
  cout << "first의 값: " << first << endl;
  cout << "second의 값: " << second << endl;
  cout << "third의 값: " << third << endl;
  cout << "fourth의 값: " << fourth;
  return 0;
}