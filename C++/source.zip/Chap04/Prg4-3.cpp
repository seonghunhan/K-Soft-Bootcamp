﻿/**************************************************************
 * if-else 조건문을 사용해서 합격/불합격 학점 찾기            *
 **************************************************************/
 #include <iostream>
using namespace std;

int main()  
{
  // 변수 선언
  int score;
  // 입력받기
  cout << "0~100점 사이의 점수를 입력하세요: ";
  cin >> score;
  // 의사 결정
  if(score  >= 70)
  {
    cout << "pass입니다." << endl;
  } // if 구문 종료
  else 
  {
   cout << "fail입니다" << endl;
  } // else 구문 종료
  return 0;  
}