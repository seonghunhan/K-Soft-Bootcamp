﻿/**************************************************************
 * C 문자열의 길이(널 문자 이전까지의 문자 개수)를            * 
 * 찾아서 출력하는 프로그램                                   *
 **************************************************************/
#include <cstring>
#include <iostream>
using namespace std;

int main()
{
  // 문자열 선언
  const char* str1 = "Hello my friends.";
  char str2[] = {'H', 'e', 'l', 'l', 'o', '\0'} ;
  // 문자열의 길이를 찾아서 출력
  cout << "str1의 길이: " << strlen(str1) << endl;
  cout << "str2의 길이: " << strlen(str2);
  return 0;
}