﻿/**************************************************************
 * strpbrk 함수를 사용해서 문자들 중에서                      *
 * 특정 문자의 위치를 찾는 프로그램                           *
 **************************************************************/
#include <cstring>
#include <iostream>
using namespace std;

int main()
{
  // 문자열 생성
  char str[] = "Hello friends of mine.";
  // 문자 집합 set 중에서 처음 등장하는 문자 탐색
  char* pPtr = strpbrk(str, "pfmd");
  cout << "찾은 문자: " << *pPtr << endl;
  cout << "해당 문자의 인덱스: " << pPtr - str;
  return 0;
}