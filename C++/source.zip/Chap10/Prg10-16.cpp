﻿/**************************************************************
 * 첨자 연산자를 사용해서 문자를 lvalue와 rvalue로 추출해서   *
 * 대문자로 변경하는 프로그램                                 *
 **************************************************************/
#include <string>
#include <iostream>

using namespace std;
int main()
{  
  string line;

  cout << "한 줄을 입력하세요: " << endl;
  getline(cin, line);
  for(int i = 0; i < line.size(); i++)
  {
    line[i] = toupper(line[i]);
  }
  cout << line;
  return 0;
} 