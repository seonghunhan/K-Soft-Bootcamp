﻿/**************************************************************
 * strcat 함수와 strncat 함수를 사용해서                      *
 * 문자열 뒤에 다른 문자열을 결합하는 프로그램                *
 **************************************************************/
#include <cstring>
#include <iostream>
using namespace std;

int main()
{
  // strcat 함수 사용
  char str1[20] = "This is ";
  const char*  str2 = "a string.";
  strcat(str1, str2);
  cout << "str1: " << str1 << endl;
  // strncat 함수 사용
  char str3[20] = "abcdefghijk";
  const char* str4 = "ABCDEFGHIJK";
  strncat(str3, str4, 4);
  cout << "str3: " << str3 << endl;
  return 0;
} 