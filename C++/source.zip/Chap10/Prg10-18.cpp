﻿/**************************************************************
 * 문자열에서 서브 문자열을                                   *
 * 추출해서 출력하는 프로그램                                 *
 **************************************************************/
#include <string>
#include <iostream>
using namespace std;

int main()
{                                 
  // 문자열 생성
  string strg("The C++ language is fun to work with.");
  // 서브 문자열 추출
  cout << strg.substr(8) << endl ;
  cout << strg.substr(4,12) << endl; 
  return 0;
}