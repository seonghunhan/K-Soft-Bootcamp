﻿/**************************************************************
 * 가장 처음에 등장하는 문자와                                * 
 * 마지막에 등장하는 문자를                                   *
 * 찾아서 출력하는 프로그램                                   *
 **************************************************************/
#include <cstring>
#include <iostream>
using namespace std;

int main()
{
  // 문자열 선언
  char str[]  = "Hello friends.";
  // 처음 등장하는 문자 e를 대문자로 변경
  char* cPtr = strchr(str, 'e');
  *cPtr = 'E';
  cout << "첫 번째 변경 후의 str: " << str << endl;
  // 마지막에 등장하는 문자 e를 대문자로 변경
  cPtr = strrchr(str, 'e');
  *cPtr = 'E';
  cout << "두 번째 변경 후의 str: " << str << endl;
  return 0;
}