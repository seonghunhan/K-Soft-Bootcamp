﻿/**************************************************************
 * getline 함수를 사용해서 문자열 읽어 들이기                 *
 **************************************************************/
#include <string>
#include <iostream>
using namespace std;

int main()
{ 
  // 빈 문자열 생성
  string strg;
  // 한 줄 읽어 들이기  
  cout << "한 줄을 입력하세요: " << endl;
  getline(cin, strg);
  cout << strg << endl << endl;
  // 여러 줄 입력받기
  cout << "여러 줄을 입력하세요(종료 때는 $ 입력): " << endl;
  getline(cin, strg, '$');
  cout << strg;
  return 0;
}