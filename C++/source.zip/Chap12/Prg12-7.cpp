﻿/*************************************************************
 * Person, Student 클래스를 사용하는 애플리케이션 파일       *
 *************************************************************/
#include "Student.h"

int main()
{
  // 다형성 변수 생성
  Person* ptr;
  // 힙에 Person 객체 인스턴스화
  ptr = new Person("Lucie");
  cout << "Person 정보" << endl;
  ptr->print();
  cout << endl;
  delete ptr;
  // 힙에 Student 객체 인스턴스화
  ptr = new Student("John", 3.9);
  cout << "Student 정보" << endl;
  ptr -> print();
  cout << endl;
  delete ptr;
  return 0;
}  