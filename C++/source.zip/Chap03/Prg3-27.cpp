﻿/************************************************************** 
 * 3개의 정수를 더하고 결과를 출력하는 프로그램               *
 **************************************************************/
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  // 변수 선언
  int first, second, third, sum;
  // 입력받기
  cout << "첫 번째 숫자 입력: ";
  cin >> first;
  cout << "두 번째 숫자 입력: ";
  cin >> second;
  cout << "세 번째 숫자 입력: ";
  cin >> third;
  // 계산
  sum = first + second + third;
  // 출력
  cout << "세 숫자의 합: " << sum;
  return 0;
}