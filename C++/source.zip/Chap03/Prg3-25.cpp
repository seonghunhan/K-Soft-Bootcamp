﻿/*********************************************************** 
 * 불 자료형을 false와 true로 입력받기                     *
 ***********************************************************/
#include <iostream>
using namespace std;

int main()
{
  // 선언
  bool flag;
  // 조정자를 사용해서 입력받기
  cout << "불 자료형을 true 또는 false로 입력: ";
  cin >> boolalpha >> flag;
  // 출력
  cout << flag ;
  return 0;      
} 