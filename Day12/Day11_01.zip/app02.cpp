//#include <iostream>
//using namespace std;
//
//class Node {
//public:
//	string data;
//	Node* link;
//};
//int main() {
//	Node* head = nullptr;
//	Node a;
//	Node b;
//	Node c;
//
//	a.data = "�����";
//	head = &a; 
//	// head->link = &a;
//	// head.link = &a;
//	b.data = "����ȣ";
//	a.link = &b;
//	b.link = nullptr;
//	
//	cout << head->link->data << "\n";
//	cout << head->data << "\n";

	//a.link = &b;
	//b.data = "����ȣ";
	//b.link = &c;
	//c.data = "���ذ�";
	////c.link = nullptr;
	//c.link = &a;

	//cout << b.data << "\n";
	//cout << a.link->data << "\n";
	//cout << a.link->link->data << "\n";
	//cout << a.link->link->link->data << "\n";
//	return 0;
//}
